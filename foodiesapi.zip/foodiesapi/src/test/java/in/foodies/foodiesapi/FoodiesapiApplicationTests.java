package in.foodies.foodiesapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodiesapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
